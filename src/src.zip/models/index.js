// src/models/index.js
module.exports = {
  Mahasiswa: require('./Mahasiswa'),
  Jadwal: require('./Jadwal'),
  Absensi: require('./Absensi'),
  Dosen: require('./Dosen'),
  MataKuliah: require('./MataKuliah'),
  Prodi: require('./Prodi'),
  Ruangan: require('./Ruangan')
};
